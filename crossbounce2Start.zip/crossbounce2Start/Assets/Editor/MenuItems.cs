﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class MenuItems {

    //allows the user to call the ShowWindow() cuntion from the GameEditorWindow script
    [MenuItem("Tools/Level Creator/Level Editor")]
    private static void ShowLevelEditor()
    {
        GameEditorWindow.ShowWindow();
    }

}