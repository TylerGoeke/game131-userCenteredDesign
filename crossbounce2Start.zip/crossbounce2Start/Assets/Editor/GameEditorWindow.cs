﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.Text;

public class GameEditorWindow : EditorWindow {

    private static GameEditorWindow instance;

    //displays the editor window when called
    public static void ShowWindow()
    {
        instance = EditorWindow.GetWindow<GameEditorWindow>();
        instance.titleContent = new GUIContent("Level Editor");
    }

    private void OnGUI()
    {
        //Provides a button that when pressed creates an instance of a wallBase prefab
        if(GUILayout.Button("Create Obstacle"))
        {
            string[] obstacleGUID = AssetDatabase.FindAssets("wallBase");

            //sends a console output for each string in obstacleGUID
            StringBuilder GuidBuilder = new StringBuilder();
            foreach(string obGuid in obstacleGUID)
            {
                GuidBuilder.AppendLine(obGuid);
            }
            UnityEngine.MonoBehaviour.print(GuidBuilder.ToString());
            // if there is a string in obstacleGUID the program continues to try to instantiate the object
            if (obstacleGUID.Length > 0)
            {
                //finds the asset path of the object and prints it to the console
                string trueObstacleGUID = obstacleGUID[0];
                string assetPath = AssetDatabase.GUIDToAssetPath(trueObstacleGUID);
                UnityEngine.MonoBehaviour.print(assetPath);

                //gets the object as a gameobject from the asset path
                GameObject obstacleTemplate = AssetDatabase.LoadAssetAtPath(assetPath, typeof(GameObject)) as GameObject;

                //instantiates the gameobject and gives it the objects name
                GameObject newObstacle = GameObject.Instantiate(obstacleTemplate);
                newObstacle.name = obstacleTemplate.name;
            }
        }

        //Provides a button that when pressed creates an instance of a target prefab
        if(GUILayout.Button("Create Target"))
        {
            string[] targetGUID = AssetDatabase.FindAssets("Target");

            StringBuilder GuidBuilder = new StringBuilder();
            foreach(string TargetGuid in targetGUID)
            {
                GuidBuilder.AppendLine(TargetGuid);
            }
            UnityEngine.MonoBehaviour.print(GuidBuilder.ToString());

            if(targetGUID.Length > 0)
            {
                string trueTargetGUID = targetGUID[0];
                string assetPath = AssetDatabase.GUIDToAssetPath(trueTargetGUID);
                UnityEngine.MonoBehaviour.print(assetPath);

                GameObject targetTemplate = AssetDatabase.LoadAssetAtPath(assetPath, typeof(GameObject)) as GameObject;

                GameObject newTarget = GameObject.Instantiate(targetTemplate);
                newTarget.name = targetTemplate.name;
            }
        }
    }


}
