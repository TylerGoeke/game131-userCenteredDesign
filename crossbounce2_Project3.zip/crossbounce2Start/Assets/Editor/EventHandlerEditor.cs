﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(EventHandler))]
public class EventHandlerEditor : Editor {

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
    }

    private void OnEnable()
    {
        ArrayList sceneViews = SceneView.sceneViews;
        if (sceneViews.Count > 0) (sceneViews[0] as SceneView).Focus();
    }

    private void OnSceneGUI()
    {
        //gives a reference to the current event
        Event currentEvent = Event.current;

        GameObject selectedObj = Selection.activeGameObject;

        //switch statement to determine the type of event and how to use it
        switch (currentEvent.type)
        {
            //case used if event is KeyDown
            case EventType.KeyDown:
                //reference for increment amount
                float incrementBy = 0.5f;
                if(currentEvent.keyCode != KeyCode.None)
                {
                    UnityEngine.MonoBehaviour.print("Key Down: " + currentEvent.keyCode);
                    
                    //the following lines move the selected object up, down, left, or right depending on which of the arrow keys are pressed

                    //moves the selected object up
                    if(currentEvent.keyCode == KeyCode.UpArrow)
                    {
                        selectedObj.transform.position = new Vector2(selectedObj.transform.position.x, selectedObj.transform.position.y + incrementBy);
                    }
                    //moves the selected object down
                    else if(currentEvent.keyCode == KeyCode.DownArrow)
                    {
                        selectedObj.transform.position = new Vector2(selectedObj.transform.position.x, selectedObj.transform.position.y - incrementBy);
                    }
                    //moves the selected object left
                    else if(currentEvent.keyCode == KeyCode.LeftArrow)
                    {
                        selectedObj.transform.position = new Vector2(selectedObj.transform.position.x - incrementBy, selectedObj.transform.position.y);
                    }
                    //moves the selected ovject right
                    else if(currentEvent.keyCode == KeyCode.RightArrow)
                    {
                        selectedObj.transform.position = new Vector2(selectedObj.transform.position.x + incrementBy, selectedObj.transform.position.y);
                    }

                    //the following lines rotate the selected object clockwise or counter clockwise depending on whether U or I are pressed

                    //rotates the object counter clockwise
                    else if(currentEvent.keyCode == KeyCode.U)
                    {
                        selectedObj.transform.Rotate(0, 0, incrementBy);
                    }
                    //rotates the object clockwise
                    else if(currentEvent.keyCode == KeyCode.I)
                    {
                        selectedObj.transform.Rotate(0, 0, -incrementBy);
                    }

                    //the following lines scale the object on the x axis depending on whether J or N is pressed
                   
                    //scales up on the x axis
                    else if(currentEvent.keyCode == KeyCode.J)
                    {
                        selectedObj.transform.localScale = new Vector3(selectedObj.transform.localScale.x + incrementBy, selectedObj.transform.localScale.y, selectedObj.transform.localScale.z);
                    }
                    //scales down on the x axis
                    else if(currentEvent.keyCode == KeyCode.N)
                    {
                        selectedObj.transform.localScale = new Vector3(selectedObj.transform.localScale.x - incrementBy, selectedObj.transform.localScale.y, selectedObj.transform.localScale.z);
                    }

                    //the following lines scale the object on the y axis depending on whether K or M is pressed

                    //scales up on the y axis
                    else if(currentEvent.keyCode == KeyCode.K)
                    {
                        selectedObj.transform.localScale = new Vector3(selectedObj.transform.localScale.x, selectedObj.transform.localScale.y + incrementBy, selectedObj.transform.localScale.z);
                    }
                    //scales down on the y axis
                    else if(currentEvent.keyCode == KeyCode.M)
                    {
                        selectedObj.transform.localScale = new Vector3(selectedObj.transform.localScale.x, selectedObj.transform.localScale.y - incrementBy, selectedObj.transform.localScale.z);
                    }

                }
                currentEvent.Use();
                break;
        }

    }
}
