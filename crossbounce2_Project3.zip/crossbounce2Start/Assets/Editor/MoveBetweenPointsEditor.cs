﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(MoveBetweenTwoPoints))]
public class MoveBetweenPointsEditor : Editor {


    public override void OnInspectorGUI()
    {
        MoveBetweenTwoPoints currentTarget = (MoveBetweenTwoPoints)target;
        //displaying float fields for the various values that can be modified
        EditorGUILayout.LabelField("End coordinates for the track");
        EditorGUILayout.LabelField("X");
        currentTarget.tempEndPosition.x = EditorGUILayout.FloatField(currentTarget.tempEndPosition.x);
        EditorGUILayout.LabelField("Y");
        currentTarget.tempEndPosition.y = EditorGUILayout.FloatField(currentTarget.tempEndPosition.y);

        EditorGUILayout.LabelField("Movement Speed");
        currentTarget.speed = EditorGUILayout.FloatField(currentTarget.speed);

        //updating position
        if (GUILayout.Button("Update Track"))
        {
            currentTarget.startPosition.x = currentTarget.transform.position.x;
            currentTarget.startPosition.y = currentTarget.transform.position.y;
            currentTarget.endPosition.x = currentTarget.tempEndPosition.x + currentTarget.transform.position.x;
            currentTarget.endPosition.y = currentTarget.tempEndPosition.y + currentTarget.transform.position.y;
        }

        //displays current track
        EditorGUILayout.LabelField("X = " + currentTarget.startPosition.x + " Y = " + currentTarget.startPosition.y);
        EditorGUILayout.LabelField("X = " + currentTarget.endPosition.x + " Y = " + currentTarget.endPosition.y);
    }
}
