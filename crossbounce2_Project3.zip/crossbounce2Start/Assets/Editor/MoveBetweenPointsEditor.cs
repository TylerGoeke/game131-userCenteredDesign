﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(MoveBetweenTwoPoints))]
public class MoveBetweenPointsEditor : Editor {

    public override void OnInspectorGUI()
    {
        MoveBetweenTwoPoints currentTarget = (MoveBetweenTwoPoints)target;
        //displaying float fields for the various values that can be modified
        EditorGUILayout.LabelField("End coordinates for the track relative to current position");
        EditorGUILayout.LabelField("X");
        currentTarget.tempEndPosition.x = EditorGUILayout.FloatField(currentTarget.tempEndPosition.x);
        EditorGUILayout.LabelField("Y");
        currentTarget.tempEndPosition.y = EditorGUILayout.FloatField(currentTarget.tempEndPosition.y);

        EditorGUILayout.LabelField("Movement Speed");
        currentTarget.speed = EditorGUILayout.FloatField(currentTarget.speed);

        //updating position
        if (GUILayout.Button("Update Track"))
        {
            currentTarget.startPosition.x = currentTarget.transform.position.x;
            currentTarget.startPosition.y = currentTarget.transform.position.y;
            currentTarget.endPosition.x = currentTarget.tempEndPosition.x + currentTarget.transform.position.x;
            currentTarget.endPosition.y = currentTarget.tempEndPosition.y + currentTarget.transform.position.y;
        }
        //switching between whether the object is moving towards its start point or end point
        if(GUILayout.Button("Switch Direction"))
        {
            currentTarget.isMovingToStart = !currentTarget.isMovingToStart;
        }
        //stating whether the object is currently moving towards start point or end point
        if(currentTarget.isMovingToStart == true)
        {
            EditorGUILayout.LabelField("Moving towards end point");
        }
        else if(currentTarget.isMovingToStart == false)
        {
            EditorGUILayout.LabelField("Moving towards start point");
        }

        //displays current track
        EditorGUILayout.LabelField("start of track");
        EditorGUILayout.LabelField(currentTarget.startPosition.x + ", " + currentTarget.startPosition.y);
        EditorGUILayout.LabelField("end of track");
        EditorGUILayout.LabelField(currentTarget.endPosition.x + ", " + currentTarget.endPosition.y);

    }
}
