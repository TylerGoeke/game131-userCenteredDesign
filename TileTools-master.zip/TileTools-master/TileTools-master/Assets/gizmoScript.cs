﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gizmoScript : MonoBehaviour {

    public int rows = 8;
    public int columns = 12;
    public float gridSize = 2.08f;

    public Color gridColor = Color.blue;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnDrawGizmos()
    {
        Gizmos.color = gridColor;
        for(int x = 0; x <= columns; x++)
        {
            Gizmos.DrawLine(new Vector3(x * gridSize, 0, transform.position.z), new Vector3(x * gridSize, rows * gridSize, transform.position.z));
        }
        for(int y = 0; y <= rows; y++)
        {
            Gizmos.DrawLine(new Vector3(0, y * gridSize, transform.position.z), new Vector3(columns * gridSize, y * gridSize, transform.position.z));
        }

        SpriteRenderer[] sprite = GameObject.FindObjectsOfType<SpriteRenderer>();
        
        for(int z = 0; z < sprite.Length; z++)
        {
            SpriteRenderer currentSprite = sprite[z];
            Sprite current = currentSprite.sprite;
            Vector3 spriteCenterWorld = currentSprite.transform.position + current.bounds.center;

            Vector3 spriteCenterGrid = new Vector3(Mathf.FloorToInt(spriteCenterWorld.x/ gridSize), Mathf.FloorToInt(spriteCenterWorld.y / gridSize), currentSprite.transform.position.z);

            currentSprite.transform.position = transform.position + spriteCenterGrid * gridSize;
        }

    }
}
